/* Automatically generated, don't edit */
/* Generated on: winnetou.amd.com */
/* At: Thu, 16 Aug 2007 19:40:13 +0000 */
/* Linux version 2.6.21-1.3194.fc7 (kojibuilder@xenbuilder4.fedora.phx.redhat.com) (gcc version 4.1.2 20070502 (Red Hat 4.1.2-12)) #1 SMP Wed May 23 22:35:01 EDT 2007 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#define CONFIG_ARCH_IA32 1
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64


/* Processor Type */
#define CONFIG_CPU_IA32_I486 1
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4
#undef  CONFIG_CPU_IA32_K8
#undef  CONFIG_CPU_IA32_C3


/* Platform */
#define CONFIG_PLAT_PC99 1

#undef  CONFIG_SMP

/* Miscellaneous */
#undef  CONFIG_IOAPIC



/* Kernel */
#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1
#undef  CONFIG_DEBUG_SYMBOLS
#undef  CONFIG_EXPERIMENTAL
#undef  CONFIG_IA32_SMALL_SPACES
#undef  CONFIG_SPIN_WHEELS
#undef  CONFIG_NEW_MDB


/* Debugger */
#define CONFIG_KDB 1

/* Kernel Debugger Console */
#define CONFIG_KDB_CONS_KBD 1
#undef  CONFIG_KDB_CONS_COM

#undef  CONFIG_KDB_DISAS
#undef  CONFIG_KDB_ON_STARTUP
#undef  CONFIG_KDB_BREAKIN
#undef  CONFIG_KDB_BREAKIN_BREAK
#undef  CONFIG_KDB_BREAKIN_ESCAPE
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#undef  CONFIG_KMEM_TRACE
#undef  CONFIG_TRACEBUFFER
#undef  CONFIG_IA32_KEEP_LAST_BRANCHES



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_AMD64_FXSR
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_BIGENDIAN
#undef  CONFIG_IA32_PGE
#undef  CONFIG_IS_64BIT
#undef  CONFIG_X86_FXSR
#define CONFIG_IS_32BIT 1
#undef  CONFIG_X86_PAT
#undef  CONFIG_FLUSHFILTER
#undef  CONFIG_AMD64_TSC
#undef  CONFIG_MULTI_ARCHITECTURE
#undef  CONFIG_IA32_PAT
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_IA32_PSE
#undef  CONFIG_IA32_TSC
#undef  CONFIG_AMD64_PAT
#undef  CONFIG_IA32_HTT
#undef  CONFIG_CPU_K8
#undef  CONFIG_X86_TSC
#undef  CONFIG_CPU_AMD64_EM64T
#undef  CONFIG_IA32_SYSENTER
/* That's all, folks! */
#define AUTOCONF_INCLUDED
