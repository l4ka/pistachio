/* Automatically generated, don't edit */
/* Generated on: nofx */
/* At: Wed, 28 Jan 2004 05:44:36 +0000 */
/* Linux version 2.6.0-test7 (benno@nofx) (gcc version 3.3.2 20031005 (Debian prerelease)) #1 Fri Oct 10 11:37:38 EST 2003 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#define CONFIG_ARCH_POWERPC 1
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4


/* Processor Type */
#define CONFIG_CPU_POWERPC_IBM750 1
#undef  CONFIG_CPU_POWERPC_PPC604


/* Platform */
#undef  CONFIG_PLAT_PC99


/* Platform */
#define CONFIG_PLAT_OFPPC 1

#undef  CONFIG_SMP

/* Miscellaneous */
#undef  CONFIG_PPC_EXPOSE_OPIC



/* Kernel */
#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1
#define CONFIG_PPC_BAT_SYSCALLS 1


/* Debugger */
#define CONFIG_KDB 1

/* Consoles */
#undef  CONFIG_KDB_CONS_OF1275
#define CONFIG_KDB_CONS_PSIM_COM 1

#undef  CONFIG_KDB_DISAS
#undef  CONFIG_KDB_ON_STARTUP
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#undef  CONFIG_TRACEPOINTS
#undef  CONFIG_KMEM_TRACE



/* Code Generator Options */
#define CONFIG_SYSV_ABI 1
#undef  CONFIG_PPC_SEGMENT_LOOP
#define CONFIG_PPC_MULTIWORD_INSTR 1


/* Derived symbols */
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_CPU_ALPHA_A21264
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_CPU_ALPHA_A21064
#define CONFIG_BIGENDIAN 1
#define CONFIG_IS_32BIT 1
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_IS_64BIT
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_ACPI
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_CPU_ALPHA_A21164
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
