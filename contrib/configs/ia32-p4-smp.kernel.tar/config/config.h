/* Automatically generated, don't edit */
/* Generated on: i30nb16 */
/* At: Tue, 16 Mar 2004 12:45:12 +0000 */
/* Linux version 2.4.25-1-686 (herbert@gondolin) (gcc version 3.3.2 (Debian)) #1 Tue Feb 24 10:55:59 EST 2004 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#define CONFIG_ARCH_IA32 1
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#define CONFIG_CPU_IA32_P4 1


/* Platform */
#define CONFIG_PLAT_PC99 1
#undef  CONFIG_PLAT_SIMICS

#define CONFIG_SMP 1
#define CONFIG_SMP_MAX_PROCS 4
#undef  CONFIG_SMP_IDLE_POLL

/* Miscellaneous */
#define CONFIG_IOAPIC 1
#define CONFIG_MAX_IOAPICS 2
#define CONFIG_APIC_TIMER_TICK 1000



/* Kernel */
#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1
#undef  CONFIG_IA32_SMALL_SPACES
#undef  CONFIG_PERFMON
#undef  CONFIG_SPIN_WHEELS


/* Debugger */
#define CONFIG_KDB 1

/* Kernel Debugger Console */
#define CONFIG_KDB_CONS_KBD 1
#undef  CONFIG_KDB_CONS_COM
#undef  CONFIG_KDB_CONS_SKI

#undef  CONFIG_KDB_DISAS
#undef  CONFIG_KDB_ON_STARTUP
#undef  CONFIG_KDB_BREAKIN
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#undef  CONFIG_KMEM_TRACE
#undef  CONFIG_TRACEBUFFER
#undef  CONFIG_IA32_KEEP_LAST_BRANCHES



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_HAVE_MEMORY_CONTROL
#define CONFIG_IA32_PGE 1
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_CPU_ALPHA_A21264
#define CONFIG_IA32_FXSR 1
#undef  CONFIG_CPU_ALPHA_A21064
#undef  CONFIG_BIGENDIAN
#define CONFIG_IS_32BIT 1
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_IS_64BIT
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_ACPI
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_CPU_ALPHA_A21164
#define CONFIG_IA32_SYSENTER 1
#define CONFIG_IA32_HTT 1
/* That's all, folks! */
#define AUTOCONF_INCLUDED
