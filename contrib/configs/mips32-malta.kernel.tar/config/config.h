/* Automatically generated, don't edit */
/* Generated on: i30nb16 */
/* At: Thu, 02 Feb 2006 14:27:34 +0000 */
/* Linux version 2.6.15-1-686 (Debian 2.6.15-3) (horms@verge.net.au) (gcc version 4.0.3 20060115 (prerelease) (Debian 4.0.2-7)) #1 Wed Jan 18 15:04:35 UTC 2006 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#define CONFIG_ARCH_MIPS32 1
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I486
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4
#undef  CONFIG_CPU_IA32_K8
#undef  CONFIG_CPU_IA32_C3


/* Processor Type */
#define CONFIG_CPU_MIPS32_m4kc 1


/* Platform */
#define CONFIG_PLAT_PC99 1


/* Platform */
#define CONFIG_PLAT_MALTA 1

#undef  CONFIG_SMP

/* Miscellaneous */
#undef  CONFIG_IOAPIC



/* Kernel */
#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1
#define CONFIG_DEBUG_SYMBOLS 1
#undef  CONFIG_EXPERIMENTAL
#undef  CONFIG_IA32_SMALL_SPACES
#undef  CONFIG_PERFMON
#undef  CONFIG_SPIN_WHEELS
#undef  CONFIG_NEW_MDB


/* Debugger */
#define CONFIG_KDB 1

/* Consoles */
#define CONFIG_KDB_CONS_OF1275 1
#define CONFIG_KDB_CONS_PSIM_COM 1


/* Kernel Debugger Console */
#undef  CONFIG_KDB_CONS_KBD
#define CONFIG_KDB_CONS_COM 1
#undef  CONFIG_KDB_CONS_SKI

#define CONFIG_KDB_COMPORT 0x3f8
#define CONFIG_KDB_COMSPEED 115200
#undef  CONFIG_KDB_DISAS
#define CONFIG_KDB_ON_STARTUP 1
#define CONFIG_KDB_BREAKIN 1
#define CONFIG_KDB_BREAKIN_BREAK 1
#define CONFIG_KDB_BREAKIN_ESCAPE 1
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#define CONFIG_VERBOSE_INIT 1
#define CONFIG_TRACEPOINTS 1
#define CONFIG_KMEM_TRACE 1



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_IS_64BIT
#undef  CONFIG_BIGENDIAN
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_SPARC64_SAB82532
#define CONFIG_IS_32BIT 1
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_ARM_BIG_ENDIAN
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_IA32_PSE
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_IA32_TSC
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_ACPI
#undef  CONFIG_SPARC64_Z8530
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
