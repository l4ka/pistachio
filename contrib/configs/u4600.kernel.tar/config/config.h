/* Automatically generated, don't edit */
/* Generated on: nofx */
/* At: Tue, 09 Dec 2003 03:52:43 +0000 */
/* Linux version 2.6.0-test7 (benno@nofx) (gcc version 3.3.2 20031005 (Debian prerelease)) #1 Fri Oct 10 11:37:38 EST 2003 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#define CONFIG_ARCH_MIPS64 1
#undef  CONFIG_ARCH_ARM
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4


/* Processor Type */
#define CONFIG_CPU_MIPS64_R4X00 1
#undef  CONFIG_CPU_MIPS64_RC64574
#undef  CONFIG_CPU_MIPS64_SB1
#undef  CONFIG_CPU_MIPS64_VR4121
#undef  CONFIG_CPU_MIPS64_VR4181


/* Platform */
#undef  CONFIG_PLAT_PC99


/* Platform */
#undef  CONFIG_PLAT_ERPCN01
#define CONFIG_PLAT_U4600 1
#undef  CONFIG_PLAT_SB1
#undef  CONFIG_PLAT_VR41XX

#undef  CONFIG_UNCACHED

/* Miscellaneous */
#define CONFIG_MAX_NUM_ASIDS 256
#undef  CONFIG_PREEMPT_ASIDS
#define CONFIG_BOOTMEM_PAGES 1024
#undef  CONFIG_MIPS64_LITTLE_ENDIAN
#define CONFIG_CPU_CLOCK_SPEED 100000



/* Kernel */
#undef  CONFIG_IPC_FASTPATH
#define CONFIG_DEBUG 1


/* Debugger */
#define CONFIG_KDB 1
#undef  CONFIG_KDB_DISAS
#undef  CONFIG_KDB_ON_STARTUP
#define CONFIG_KDB_BREAKIN 1
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#undef  CONFIG_KMEM_TRACE



/* Code Generator Options */


/* Derived symbols */
#define CONFIG_HAVE_MEMORY_CONTROL 1
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_CPU_ALPHA_A21264
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_CPU_ALPHA_A21064
#define CONFIG_BIGENDIAN 1
#undef  CONFIG_IS_32BIT
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_SWIZZLE_IO_ADDR
#define CONFIG_IS_64BIT 1
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_ACPI
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_CPU_ALPHA_A21164
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
