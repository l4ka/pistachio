/* Automatically generated, don't edit */
/* Generated on: nofx */
/* At: Mon, 02 Feb 2004 05:06:54 +0000 */
/* Linux version 2.6.0-test7 (benno@nofx) (gcc version 3.3.2 20031005 (Debian prerelease)) #1 Fri Oct 10 11:37:38 EST 2003 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#undef  CONFIG_ARCH_AMD64
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#define CONFIG_ARCH_ARM 1
#undef  CONFIG_ARCH_SPARC64


/* Processor Type */
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4


/* Processor Type */
#define CONFIG_CPU_ARM_SA1100 1


/* Platform */
#undef  CONFIG_PLAT_PC99


/* Platform */
#define CONFIG_PLAT_PLEB 1


/* Miscellaneous */
#undef  CONFIG_ENABLE_FASS



/* Kernel */
#define CONFIG_DEBUG 1


/* Debugger */
#define CONFIG_KDB 1
#undef  CONFIG_KDB_ON_STARTUP
#define CONFIG_KDB_BREAKIN 1
#undef  CONFIG_KDB_NO_ASSERTS

/* Trace Settings */
#undef  CONFIG_VERBOSE_INIT
#define CONFIG_TRACEPOINTS 1
#undef  CONFIG_KMEM_TRACE



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_HAVE_MEMORY_CONTROL
#undef  CONFIG_IA32_PGE
#undef  CONFIG_PLAT_OFSPARC64
#undef  CONFIG_CPU_ALPHA_A21264
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_CPU_ALPHA_A21064
#undef  CONFIG_BIGENDIAN
#define CONFIG_IS_32BIT 1
#undef  CONFIG_CPU_SPARC64_ULTRASPARC
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_IS_64BIT
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_SPARC64_ULTRASPARC2I
#undef  CONFIG_SPARC64_ULTRASPARC1
#undef  CONFIG_SPARC64_ULTRASPARC2
#undef  CONFIG_ACPI
#undef  CONFIG_ALPHA_FASTPATH
#undef  CONFIG_CPU_ALPHA_A21164
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
